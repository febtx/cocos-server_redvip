
var path         = require('path');
var fs           = require('fs');

var Helpers      = require('../Helpers/Helpers');

var UserInfo     = require('../Models/UserInfo');
var BauCua_phien = require('../Models/BauCua/BauCua_phien');
var BauCua_cuoc  = require('../Models/BauCua/BauCua_cuoc');
var BauCua_user  = require('../Models/BauCua/BauCua_user');
var BauCua_temp  = require('../Models/BauCua/BauCua_temp');

var bot        = require('./baucua/bot');
var botList    = [];

var dataBauCua = '../../data/baucua.json';

var io       = null;
var gameLoop = null;

function init(obj){
	io = obj;
	io.BauCua_phien = 1;
	io.baucua = {ingame:[]};
	io.baucua.info = {
		redBau: 0,
		redCa: 0,
		redCua: 0,
		redGa: 0,
		redHuou: 0,
		redTom: 0,
		xuBau: 0,
		xuCa: 0,
		xuCua: 0,
		xuGa: 0,
		xuHuou: 0,
		xuTom: 0,
	};

	BauCua_phien.findOne({}, 'id', {sort:{'_id':-1}}, function(err, last) {
		if (!!last){
			io.BauCua_phien = last.id+1;
		}
		playGame();
	})
}

function thongtin_thanhtoan(dice = null){
	if (!!dice) {
		var heSo   = {}; // Hệ số nhân
		for (var i = 0; i < 3; i++) {
			var dataT = dice[i];
			if (void 0 === heSo[dataT]) {
				heSo[dataT] = 1;
			}else{
				heSo[dataT] += 1;
			}
		}
		var updateLog = {};
		for (var j = 0; j < 6; j++) {
			if (void 0 !== heSo[j]) {
				updateLog[j] = heSo[j];
			}
		}
		var phien = io.BauCua_phien-1;
		BauCua_temp.updateOne({}, {$inc: updateLog}).exec();
		BauCua_cuoc.find({phien: phien}, {}, function(err, list) {
			if (list.length) {
				Promise.all(list.map(function(cuoc){
					var TienThang = 0; // Số tiền thắng (chưa tính gốc)
					var TongThua  = 0; // Số tiền thua
					var TongThang = 0; // Tổng tiền thắng (đã tính gốc)
					var thuong    = 0;
					var huou      = 0;
					var bau       = 0;
					var ga        = 0;
					var ca        = 0;
					var cua       = 0;
					var tom       = 0;

					// Cược Hươu
					if (cuoc[0] > 0) {
						if (void 0 !== heSo[0]) {
							huou = (cuoc[0]*heSo[0]);
							TienThang += huou;
							TongThang += cuoc[0]+huou;
						}else{
							TongThua  += cuoc[0];
						}
					}
					// Cược Bầu
					if (cuoc[1] > 0) {
						if (void 0 !== heSo[1]) {
							bau = (cuoc[1]*heSo[1]);
							TienThang += bau;
							TongThang += cuoc[1]+bau;
						}else{
							TongThua  += cuoc[1];
						}
					}
					// Cược Gà
					if (cuoc[2] > 0) {
						if (void 0 !== heSo[2]) {
							ga = (cuoc[2]*heSo[2]);
							TienThang += ga;
							TongThang += cuoc[2]+ga;
						}else{
							TongThua  += cuoc[2];
						}
					}
					// Cược Cá
					if (cuoc[3] > 0) {
						if (void 0 !== heSo[3]) {
							ca = (cuoc[3]*heSo[3]);
							TienThang += ca;
							TongThang += cuoc[3]+ca;
						}else{
							TongThua  += cuoc[3];
						}
					}
					// Cược Cua
					if (cuoc[4] > 0) {
						if (void 0 !== heSo[4]) {
							cua = (cuoc[4]*heSo[4]);
							TienThang += cua;
							TongThang += cuoc[4]+cua;
						}else{
							TongThua  += cuoc[4];
						}
					}
					// Cược Tôm
					if (cuoc[5] > 0) {
						if (void 0 !== heSo[5]) {
							tom = (cuoc[5]*heSo[5]);
							TienThang += tom;
							TongThang += cuoc[5]+tom;
						}else{
							TongThua  += cuoc[5];
						}
					}

					var tongDat    = cuoc[0]+cuoc[1]+cuoc[2]+cuoc[3]+cuoc[4]+cuoc[5];

					var update     = {};
					var updateGame = {};

					cuoc.thanhtoan = true;
					cuoc.betwin    = TongThang;
					cuoc.save();

					if (cuoc.red) {
						//RED
						if (TongThang > 0) {
							update['red'] = TongThang;
						}
						if (TienThang > 0) {
							update['redWin'] = updateGame['red'] = TienThang;
						}
						if (TongThua > 0) {
							update['redLost'] = updateGame['red_lost'] = TongThua;
						}

						update['redPlay'] = updateGame['redPlay'] = tongDat;

						UserInfo.updateOne({id:cuoc.uid}, {$inc:update}).exec();
						BauCua_user.updateOne({uid: cuoc.uid}, {$inc:updateGame}).exec();
					}else{
						//XU
						if (TongThang > 0) {
							update['xu'] = TongThang;
						}
						if (TienThang > 0) {
							thuong = (TienThang*0.039589)>>0;
							update['xuWin'] = updateGame['xu'] = TienThang;
							update['red']   = update['thuong'] = updateGame['thuong'] = thuong;
						}
						if (TongThua > 0) {
							update['xuLost'] = updateGame['xu_lost'] = TongThua;
						}

						update['xuPlay'] = updateGame['xuPlay'] = tongDat;

						UserInfo.updateOne({id:cuoc.uid}, {$inc:update}).exec();
						BauCua_user.updateOne({uid: cuoc.uid}, {$inc:updateGame}).exec();
					}
					if(void 0 !== io.users[cuoc.uid]){
						if (TongThang > 0) {
							var status = {mini:{baucua:{status:{win:true, bet: TongThang, thuong: thuong}}}};
						}else{
							var status = {mini:{baucua:{status:{win:false, bet: TongThua}}}};
						}
						Promise.all(io.users[cuoc.uid].map(function(client){
							client.red(status);
						}));
					}
					return {users: cuoc.name, bet: TienThang};
				}))
				.then(function(arrayOfResults) {
					Promise.all(arrayOfResults.filter(function(st){
						return !!st;
					}))
					.then(result => {
						if (result.length) {
							result.sort(function(a, b){
								return b.bet-a.bet;
							});

							result = result.slice(0, 10);
							result = Helpers.shuffle(result);

							Promise.all(result.map(function(obj){
								return {users: obj.users, bet: Helpers.numberWithCommas(obj.bet), game: 'Bầu Cua'};
							}))
							.then(results => {
								results = {news:{a:results}};
								Promise.all(Object.values(io.users).map(function(users){
									Promise.all(users.map(function(client){
										if(client.scene == "home"){
											client.red(results);
										}
									}));
								}));
								io.sendAllClient(results);
							});
						}
					})
					playGame();
				});
			}else{
				playGame();
			}
		});
	}else{
		Promise.all(Object.values(io.users).map(function(users){
			Promise.all(users.map(function(client){
				if (client.gameEvent !== void 0 && client.gameEvent.viewBauCua !== void 0 && client.gameEvent.viewBauCua)
					client.red({mini:{baucua:{data: io.baucua.info}}});
			}));
		}));
		var admin_data = {baucua:{info: io.baucua.info, ingame: io.baucua.ingame}};
		Promise.all(Object.values(io.admins).map(function(admin){
			Promise.all(admin.map(function(client){
				if (client.gameEvent !== void 0 && client.gameEvent.viewBauCua !== void 0 && client.gameEvent.viewBauCua)
					client.red(admin_data);
			}));
		}));
	}
}

function playGame(){
	io.BauCua_time = 71;
	//io.BauCua_time = 15;

	gameLoop = setInterval(function(){
		io.BauCua_time--;
		if (io.BauCua_time <= 60) {
			if (io.BauCua_time < 0) {
				clearInterval(gameLoop);
				io.BauCua_time = 0;

				var file  = require(dataBauCua);

				var dice1 = file[0] == 6 ? (Math.random()*6)>>0 : file[0];
				var dice2 = file[1] == 6 ? (Math.random()*6)>>0 : file[1];
				var dice3 = file[2] == 6 ? (Math.random()*6)>>0 : file[2];

				file[0]     = 6;
				file[1]     = 6;
				file[2]     = 6;
				file.uid    = "";
				file.rights = 2;

				fs.writeFile(path.dirname(path.dirname(__dirname)) + "/data/baucua.json", JSON.stringify(file), function(err){});

				BauCua_phien.create({'dice1':dice1, 'dice2':dice2, 'dice3':dice3, 'time':new Date()}, function(err, create){
					if (!!create) {
						io.BauCua_phien = create.id+1;

						var chothanhtoan = thongtin_thanhtoan([dice1, dice2, dice3]);

						Promise.all(Object.values(io.users).map(function(users){
							Promise.all(users.map(function(client){
								client.red({mini: {baucua: {finish:{dices:[create.dice1, create.dice2, create.dice3], phien:create.id}}}});
							}));
						}));

						Promise.all(Object.values(io.admins).map(function(admin){
							Promise.all(admin.map(function(client){
								client.red({baucua: {finish: true, dices:[create.dice1, create.dice2, create.dice3]}});
							}));
						}));
					}
				});
				io.baucua.ingame = [];
				io.baucua.info = {
					redBau: 0,
					redCa: 0,
					redCua: 0,
					redGa: 0,
					redHuou: 0,
					redTom: 0,
					xuBau: 0,
					xuCa: 0,
					xuCua: 0,
					xuGa: 0,
					xuHuou: 0,
					xuTom: 0,
				};

				var config = require('../../config/baucua.json');
				if (config.bot) {
					// lấy danh sách tài khoản bot
					var TList = bot.list();
					TList.then(resultBot => {
						botList = Helpers.shuffle(resultBot); // tráo bot;
					});
				}else{
					botList = [];
				}
			}else{
				thongtin_thanhtoan();
				if (!!botList.length && io.TaiXiu_time > 5) {
					var userCuoc = (Math.random()*5)>>0;
					for (var i = 0; i < userCuoc; i++) {
						var dataT = botList[i];
						if (!!dataT) {
							bot.bet(dataT, io);
							botList.splice(i, 1); // Xoá bot đã đặt tránh trùng lặp
						}
					}
				}
			}
		}
	}, 1000);
	return gameLoop
}

module.exports = init;
