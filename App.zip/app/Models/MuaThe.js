
const AutoIncrement = require('mongoose-auto-increment-reworked').MongooseAutoIncrementID;
const mongoose = require("mongoose");

const Schema = new mongoose.Schema({
	uid:     {type: String, required: true}, // ID người chơi
	nhaMang: {type: String, required: true}, // Nhà mạng
	menhGia: {type: Number, required: true}, // Mệnh giá
	soLuong: {type: Number, required: true}, // Số lượng
	Cost:    {type: Number, required: true}, // Chi Phí
	status:  {type: Number, default:  0},    // Trạng thái mua
	time:    Date,                           // Thời gian mua
});

Schema.plugin(AutoIncrement.plugin, {modelName: 'MuaThe', field:'GD'});
Schema.index({uid: 1}, {background: true});

module.exports = mongoose.model("MuaThe", Schema);
