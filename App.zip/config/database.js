
module.exports = {
	"url": "mongodb://127.0.0.1:27017",
	//"url": "mongodb://163.44.207.163:27017",
	"options": {
		//"user":   "admin",
		//"pass":   "MrT98TT2",
		"dbName": "red",
		"useNewUrlParser": true,
		//"autoIndex":       false,
	},
};
