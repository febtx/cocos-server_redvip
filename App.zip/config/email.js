
module.exports = {
	"user": "redvip.otp@gmail.com",
	"pass": "thaython123",
}
