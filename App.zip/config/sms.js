
module.exports = {
	"URL":        "http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get",
	"API_KEY":    "57691BC8E328DABB0A650F6B2A451C",
	"SECRET_KEY": "303E7FA109BCC4A7F85B35FA74E209",
	"Brandname":  "RedVip",
}
