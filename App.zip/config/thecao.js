
module.exports = {
	"extract":      0,                                         // Chiết khẩu 0%
	"URL":          "http://redpay.vn/api/service/chargeCard", // URL API
	"APP_ID":       1,                                         // id app
    "APP_PASSWORD": "76cc1038407439dc874e37ebd9377925",        // pass app

    "00": "Nạp thẻ cào thành công",
	"99": "Lỗi, không rõ nguyên nhân",
	"01": "Lỗi, truy cập bị từ chối",
	"02": "Lỗi, dữ liệu gửi lên không chính xác",
	"03": "Lỗi, Nạp đang bị khóa",
	"04": "Lỗi, Mã checksum không chính xác",
	"05": "Tài khoản nhận tiền nạp của merchant không tồn tại",
	"06": "Tài khoản nhận tiền nạp của merchant đang bị khóa hoặc bị phong tỏa, không thể thực hiện được giao dịch nạp tiền",
	"07": "Thẻ đã được sử dụng ",
	"08": "Thẻ bị khóa",
	"09": "Thẻ hết hạn sử dụng",
	"10": "Thẻ chưa được kích hoạt hoặc không tồn tại",
	"11": "Mã thẻ sai định dạng",
	"12": "Sai số serial của thẻ",
	"13": "Mã thẻ và số serial không khớp",
	"14": "Thẻ không tồn tại",
	"15": "Thẻ không sử dụng được",
	"16": "Số lần thử (nhập sai liên tiếp) của thẻ vượt quá giới hạn cho phép",
	"17": "Hệ thống Telco bị lỗi hoặc quá tải, thẻ chưa bị trừ",
	"18": "Đã gửi yêu cầu nạp thẻ. Chờ xác nhận",
	"19": "Không thể kết nối tới máy chủ.",
	"20": "Đã gửi yêu cầu nạp thẻ.",
	"21": "Khách hàng đang nạp thẻ bị khóa",
	"22": "Mệnh giá thẻ không hợp lệ",
};
